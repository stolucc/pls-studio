## ----knitr-settings, include = FALSE------------------------------------------
knitr::opts_chunk$set(
  eval = FALSE,
  collapse = TRUE,
  comment = "#>"
)

## ----install-qs-qs2, eval = FALSE---------------------------------------------
# pak::pkg_install(c(
#   "stringfish@0.18.0",
#   "url::https://cran.r-project.org/src/contrib/Archive/qs/qs_0.27.3.tar.gz",
#   "qs2"
# ))

## ----open-qs, eval = FALSE----------------------------------------------------
# df <- qs::qread(file = 'path_to_qs_file.qs')

## ----save-qs2, eval = FALSE---------------------------------------------------
# qs2::qs_save(object = df, file = 'path_to_save_qs2_file.qs2')


#' @export
pmvt.alt <- function (low, upp, corr, df)
{
  integrand <- function(arg, df) {
    ff <- dmvt(arg, sigma = corr, df = df, log = FALSE)
    return(ff)
  }
  # (cubature is a suggested package, PLS Studio patch: it does not load in webR, and only this function needs it)
  if (!requireNamespace("cubature", quietly = TRUE))
    stop("pmvt.alt() (a Student's t copula with a non-integer df) needs the cubature package, which is not installed (or cannot be loaded here); install.packages(\"cubature\").", call. = FALSE)
  cubature::cuhre(f = integrand, df = df, lowerLimit = low, upperLimit = upp)$integral
}

#' Holzinger & Swineford (1939) Data
#'
#' Subset of 301 students from classic Holzinger & Swineford (1939) data with 9 mental ability scores
#'
#'
#' @format ## 'Holzinger'
#' A data frame with 10 columns and 301 rows
#' \describe{
#' \item{id}{student identification number}
#' \item{x1}{Visual Perception score}
#' \item{x2}{Cubes score}
#' \item{x3}{Lozenges score}
#' \item{x4}{Paragraph Comprehension score}
#' \item{x5}{Sentence Completion score}
#' \item{x6}{Word Meaning score}
#' \item{x7}{Speeded Addition score}
#' \item{x8}{Speended Dot Counting score}
#' \item{x9}{Speeded Letter Discrimination score}
#' }
#' @source lavaan R package \url{https://github.com/yrosseel/lavaan/tree/master/data}
#'
#' @references Holzinger, K., & Swineford, F. (1939). A study in factor analysis: The stability of a bifactor solution. Supplementary Educational Monograph, no. 48. Chicago: University of Chicago Press.
#'
"Holzinger"
